<?php 
mysql_connect("localhost","root","password");
mysql_select_db("online_shop");
?>