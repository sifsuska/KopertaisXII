<div class="footer">
	<hr>
	<p>
		<a href="../aplikasi/index.php" class="href">BERANDA</a> | 
		<a href="../footer/check.php" class="href">DASHBOARD</a><br/><br/>
		Copyright&copy; Pendi Setiawan
	</p>
</div>