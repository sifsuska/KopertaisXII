<?php 
header('Location: aplikasi');
?>